package com.atguigu.dao;

import com.atguigu.pojo.Order;

public interface OrderDao {

    public int saveOrder(Order order);

}
